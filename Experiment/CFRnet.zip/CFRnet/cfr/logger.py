class Logger():
    VERBOSE = False
